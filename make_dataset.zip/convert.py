#根据txt的label和jpeg生成xml文件
import cv2
import os
xml_head = '''<annotation>
    <folder>VOC2007</folder>
    <!--filename-->
    <filename>{}</filename>.
    <source>
        <database>The VOC2007 Database</database>
        <annotation>PASCAL VOC2007</annotation>
        <image>flickr</image>
        <flickrid>325991873</flickrid>
    </source>
    <owner>
        <flickrid>null</flickrid>
        <name>null</name>
    </owner>    
    <size>
        <width>{}</width>
        <height>{}</height>
        <depth>{}</depth>
    </size>
    <segmented>0</segmented>
    '''
xml_obj = '''
    <object>        
        <name>{}</name>
        <pose>Rear</pose>
        <!--0 means assertive, 1 means unassertive-->
        <truncated>0</truncated>
        <!--0 means easy to detect,1 mean hard to detect-->
        <difficult>0</difficult>
        <!--four coordinates of bounding box-->
        <bndbox>
            <xmin>{}</xmin>
            <ymin>{}</ymin>
            <xmax>{}</xmax>
            <ymax>{}</ymax>
        </bndbox>
    </object>
    '''
xml_end = '''
</annotation>'''
 

txt_path = "E:/download/DataLib/Wilder_Face/wider_face_split/wider_face_train_bbx_gt.txt"
imgs_path = "E:/download/DataLib/Wilder_Face/WIDER_train/WIDER_train/images/"
labels = 'face'                #label for datasets
 
cnt = 0
cnt_line = 0
with open(txt_path,'r',encoding='utf8') as train_list:
    lst = train_list.readlines()
    while (cnt_line < len(lst)):
        img_name = lst[cnt_line]
        if '.jpg' in img_name:
            per_nums = int(lst[cnt_line + 1].rstrip())
            per_lines = lst[cnt_line + 2:cnt_line+2+per_nums]
            cnt_line = cnt_line + per_nums + 2

            if per_nums == 0:
                cnt_line += 1
                continue

            # process one image
            img_path = imgs_path + img_name.rstrip()
            if not os.path.exists(img_path):
                print(img_path)
            img = cv2.imread(img_path)
            img_h,img_w = img.shape[0],img.shape[1]
            head = xml_head.format(str(img_path),str(img_w),str(img_h),3)

            obj = ''

            out_txt_name = "E:/download/DataLib/Wilder_Face/train_xml/" + img_path.split('/')[-1].replace('.jpg', '.xml')
            for f in per_lines:
                f = [int(x) for x in f.rstrip().split(' ')]
                if f[2]*f[3] < 10:
                    continue
                xmin = str(f[0])
                ymin = str(f[1])
                xmax = str(f[0] + f[2])
                ymax = str(f[1] + f[3])

                obj += xml_obj.format(labels,xmin,ymin,xmax,ymax)
            
            if obj == '':
                continue

            with open(out_txt_name,'w') as f_xml:
                f_xml.write(head+obj+xml_end)
            cnt += 1
            print(cnt)
            if cnt == 279:
                temp = 1
