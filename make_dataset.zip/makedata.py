#把不同catalog的文件放到同一个总文件夹中
import os
import shutil
#test数据集的目录
WIDER_test = "WIDER_test/images"
TEST_Catalog = os.listdir(WIDER_test)
TEST_Folder = "WIDER_test/images/JPEGImages"
#val数据集得目录
WIDER_val = "WIDER_val/images"
VAL_Catalog = os.listdir(WIDER_val)
VAL_Folder  = "WIDER_val/JPEGImages"



for catalog in VAL_Catalog:
    jpeg_list = os.listdir(os.path.join(WIDER_val,catalog))
    for jpeg in jpeg_list:
        dir = os.path.join(os.path.join(WIDER_val,catalog),jpeg)
        shutil.copy(dir,VAL_Folder)
    print(catalog+"is done")
