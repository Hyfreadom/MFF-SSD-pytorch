#检查xml和jpeg中不相同的文件
import os
xmlfilepath = "Annotations"
temp_xml        = os.listdir(xmlfilepath)
jpegfilepath = "JPEGImages"
temp_jpeg       = os.listdir(jpegfilepath)


xml = []
for item in temp_xml:
    xml.append(item[:-4])


jpeg = []
for item in temp_jpeg:
    jpeg.append(item[:-4])


for pic in jpeg:
    if pic not in xml:
        print(pic)
for label in xml:
    if label not in jpeg:
        print(label)
