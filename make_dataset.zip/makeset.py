#制作imageset 文本文件
import os
train_filelist   = os.listdir('JPEGImages')
test_filelist    = os.listdir('test_JPEGImages')
val_filelist     = os.listdir('val_JPEGImages')

targetfile = 'test.txt'
srcfile    = test_filelist
with open(targetfile,'w',encoding='utf-8') as file:
    for str in srcfile:
        file.writelines(str[:-4]+'\n')
file.close()